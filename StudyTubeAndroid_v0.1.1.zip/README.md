# StudyTube Android prototype — v0.1.1

The channel limit is **10**.

## Included
- Native Android starter project using Kotlin and Jetpack Compose
- Minimal dark interface
- Manually add up to ten YouTube channel URLs or @handles
- Remove channels
- Locally persist the allowlist using Android DataStore
- Basic input validation

## Not yet included
- Resolving channel URLs and @handles to canonical YouTube channel IDs
- Fetching uploads through YouTube Data API v3
- Video browsing and official embedded player
- Viewing timer or study-session lock

## Build
Open this folder in Android Studio, allow Gradle sync, then run on an Android device or emulator. This is source code, not a compiled APK.

## Next milestones
1. Resolve and validate channel identities.
2. Fetch uploads only from approved channels using YouTube Data API v3.
3. Display a simple, finite video list.
4. Play using the official YouTube embedded player.
5. Add an optional daily viewing limit.

The embedded YouTube player must retain required standard functionality. The app can avoid building its own recommendation feed, but should not remove or interfere with YouTube player controls or required related-video behavior. Temporary buffering/cache may still occur during streaming.
