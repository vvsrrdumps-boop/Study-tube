package com.studytube.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.map
import android.content.Context

private val Context.dataStore by preferencesDataStore(name = "studytube_settings")
private val CHANNELS_KEY = stringSetPreferencesKey("approved_channels")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyTubeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyTubeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val channels by context.dataStore.data.map {
        it[CHANNELS_KEY] ?: emptySet()
    }.collectAsState(initial = emptySet())

    var channelInput by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val green = Color(0xFFB9E4C7)
    val muted = Color(0xFFAAB5AC)
    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF101411), surface = Color(0xFF1B241E),
        primary = green, onPrimary = Color(0xFF102016),
        onBackground = Color(0xFFF2F5F2), onSurface = Color(0xFFF2F5F2)
    )) {
        Scaffold(containerColor = Color(0xFF101411)) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircle, null, tint = green, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("StudyTube", style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                        Text("Your learning feed. Your rules.", color = muted,
                            style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(color = Color(0xFF1B241E), shape = RoundedCornerShape(50)) {
                        Text("${channels.size}/10 channels", color = green,
                            Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
                Spacer(Modifier.height(26.dp))
                Text("APPROVED CHANNELS", color = muted, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(10.dp))
                if (channels.isEmpty()) {
                    Surface(color = Color(0xFF1B241E), shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PlayCircle, null, tint = green, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Your feed is intentionally empty", fontWeight = FontWeight.SemiBold)
                            Text("Add up to ten channels you trust. Video browsing comes in the next build.",
                                color = muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)) {
                        items(channels.toList().sorted(), key = { it }) { channel ->
                            Surface(color = Color(0xFF1B241E), shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayCircle, null, tint = green)
                                    Spacer(Modifier.width(8.dp))
                                    Text(channel, Modifier.weight(1f))
                                    IconButton(onClick = {
                                        scope.launch {
                                            context.dataStore.edit { p ->
                                                p[CHANNELS_KEY] = (p[CHANNELS_KEY] ?: emptySet()) - channel
                                            }
                                        }
                                    }) { Icon(Icons.Default.DeleteOutline, "Remove channel", tint = muted) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("ADD A CHANNEL", color = muted, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = channelInput, onValueChange = { channelInput = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Paste a YouTube channel URL or @handle") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    val value = channelInput.trim().removeSuffix("/")
                    val valid = value.startsWith("@") || value.startsWith("UC") ||
                        value.contains("youtube.com/")
                    when {
                        value.isBlank() -> error = "Enter a channel URL or @handle."
                        !valid -> error = "Use a YouTube channel URL or @handle."
                        value in channels -> error = "That channel is already on your list."
                        channels.size >= 10 -> error = "You have reached the ten-channel limit."
                        else -> {
                            scope.launch {
                                context.dataStore.edit { p ->
                                    p[CHANNELS_KEY] = (p[CHANNELS_KEY] ?: emptySet()) + value
                                }
                            }
                            channelInput = ""; error = null
                        }
                    }
                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add to my channels")
                }
                if (error != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(error!!, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(18.dp))
                Surface(color = Color(0xFF18231C), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Distraction-free by design", color = green, fontWeight = FontWeight.SemiBold)
                        Text("No Shorts tab • No app-made recommendations • No downloads",
                            color = muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Prototype v0.1.1 • Channel list saved on this device",
                    color = muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
